module.exports = {
  User: require("./User"),
  Bike: require("./Bike"),
  Reservation: require("./Reservation")
 };
