module.exports = {
  bikes: "/bikes",
  reservation: "/reservation",
  cancelBooking: "/cancelReservation",
  myReservation: "/myReservation",
  giveFeedBack: "/submitReview",
  login: "/auth/login",
  signup: "/auth/signup",
  users: "/users",
  bikeUsers: '/bikesUser'
}
