import React from 'react'

export default function Bikes() {
  return (
    <div>Bikes</div>
  )
}
