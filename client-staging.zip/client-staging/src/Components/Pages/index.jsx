export { default } from "./Pages";

